import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import {
  getFirestore,
  initializeFirestore,
  persistentLocalCache,
  type Firestore,
} from 'firebase/firestore';

const firebaseConfig = {
  apiKey: 'AIzaSyBy3o2aes3pe9nu11sxwuOVKvFPU--Ry3o',
  authDomain: 'foco-d6288.firebaseapp.com',
  projectId: 'foco-d6288',
  storageBucket: 'foco-d6288.firebasestorage.app',
  messagingSenderId: '380728956339',
  appId: '1:380728956339:web:711d2151f94d377c27a7c6',
};

export const firebaseApp = initializeApp(firebaseConfig);
export const auth = getAuth(firebaseApp);

function createDb(): Firestore {
  try {
    return initializeFirestore(firebaseApp, { localCache: persistentLocalCache() });
  } catch {
    return getFirestore(firebaseApp);
  }
}

export const db = createDb();
