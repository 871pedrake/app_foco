# Sistema de XP por Habilidade, 15 Níveis Detalhados e Auditoria Completa de Bugs

Este plano adiciona progressão gamificada ao **Foco**, concedendo **+1 XP** por cada habilidade/tarefa concluída, com **15 níveis detalhados**, painel de **Combo Diário**, resumo de **XP ganho hoje** e uma fase abrangente de testes e correção de bugs em todos os módulos do aplicativo.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> As preferências abaixo foram confirmadas na etapa de alinhamento e orientam toda a construção:

- **Modelo de XP Confirmado**: Cada conclusão de habilidade/tarefa concede **+1 XP** tanto para o **Nível Geral do Usuário** quanto para o **XP próprio daquela habilidade/tarefa** (mostrando a evolução individual de cada hábito ou tarefa única).
- **Progressão em 15 Níveis**: Criação de **15 níveis detalhados**, cada um com faixa de XP própria, título de patente, subtítulo, descrição completa do estágio de disciplina e meta para o próximo nível.
- **Elementos Inspirados na Referência**: Inclusão da barra de **Combo Diário**, cartão de **XP ganho hoje** na área de tarefas e uma **tela dedicada de Níveis & XP** acessível na barra principal.
- **Comportamento ao Desmarcar**: Desmarcar uma habilidade concluída remove o **+1 XP** ganho naquele ciclo e ajusta o registro correspondente, impedindo XP fantasma por cliques repetidos.

---

## 1. Overview & Core Concept

- **O Que Faz**: Transforma cada tarefa diária ou única do Foco em uma habilidade treinável que soma **+1 XP** a cada conclusão real. O usuário acompanha seu ganho diário em tempo real (**Combo Diário** e **XP ganho hoje**), vê o nível individual de cada tarefa e explora uma trilha completa com **15 níveis detalhados** de evolução pessoal.
- **Público-Alvo**: Usuários que buscam transformar consistência diária, hábitos e foco em uma progressão visível, justa e motivadora, sem distrações visuais ou poluição sonora.
- **Valor Principal**: Conecta ação imediata (+1 XP ao marcar uma habilidade) com visão de longo prazo (15 níveis claros e histórico preservado) e eleva a confiabilidade de todo o app através de uma bateria completa de caça a bugs.

---

## 2. User Experience & Visual Design

### Fluxos Principais do Usuário

1. **Conclusão e Ganho de +1 XP na Aba de Tarefas**:
   - Na lista de habilidades (Diárias e Únicas), o usuário visualiza o indicador limpo de recompensa (`+1 XP`) e a evolução individual daquela habilidade (XP acumulado e patente da habilidade).
   - Ao marcar uma habilidade como concluída:
     - O contador de **XP ganho hoje** sobe imediatamente em `+1 XP`.
     - A barra de **Combo Diário** avança (ex.: `2 / 5 habilidades hoje`), celebrando quando todas as diárias do dia são concluídas.
     - O nível geral do usuário e o nível da habilidade atualizam em tempo real, disparando feedback sonoro discreto (quando o som está ativo) e aviso toast de subida de nível quando uma nova patente dos 15 níveis é alcançada.
   - Ao desmarcar a habilidade, o `+1 XP` do dia e o registro associado são revertidos com segurança (nunca ficando abaixo de zero).

2. **Tela Dedicada de Níveis & XP**:
   - Acessível pela navegação principal (`Níveis & XP`), apresenta:
     - **Cartão Principal de Patente Atual**: Nível atual (de 1 a 15), título, descrição detalhada do estágio, barra de progresso numérica (`XP atual / XP do próximo nível`) e resumo de XP total, XP de hoje e total de habilidades evoluídas.
     - **Ranking de Habilidades (XP Próprio)**: Lista ordenada das tarefas/habilidades com maior XP acumulado, exibindo conclusões totais, XP próprio e estágio individual de maestria.
     - **Trilha dos 15 Níveis Detalhados**: Mapa completo do Nível 1 ao Nível 15 exibindo requisitos de XP, título, descrição detalhada do comportamento/hábito esperado naquela fase e indicação clara de níveis já desbloqueados, nível atual e próximos objetivos.

3. **Auditoria de Bugs em Todo o App**:
   - Revisão sistemática dos fluxos de Tarefas (edição, remoção, limpeza, simulação de dia, virada de meia-noite), XP/Níveis (hidratação de dados antigos, desmarcação de tarefas de dias anteriores), Calendário/Heatmap, Diário, Vícios/Recaídas com Comentário, Motor de Áudio (5 músicas + 6 ambientes aleatórios + troca automática + upload customizado) e alternância de Tema Claro/Escuro.

### Identidade Visual & Diretrizes de Interface

- **Direção Estética**: Continuação fiel do estilo utilitário minimalista e editorial do Foco — superfícies planas de elevação única com bordas finas (`1px`), contraste nítido em **Modo Claro e Modo Escuro** e hierarquia tipográfica clara.
- **Paleta & Superfícies (60-30-10)**:
  - *Canvas Neutro (60%)*: Ardósia clara suave no modo claro e ardósia profunda (`#020617` / `#0f172a`) no modo escuro.
  - *Superfícies Estruturais (30%)*: Painéis com bordas sutis e divisores finos, evitando cartões aninhados pesados ou barras laterais grossas coloridas.
  - *Acentos Intencionais (10%)*: Índigo para progresso de XP, barras de Combo Diário e ações principais; esmeralda para metas diárias concluídas e níveis alcançados; âmbar para marcos especiais.
- **Tipografia & Números Tabulares**:
  - Manutenção de `Plus Jakarta Sans` e `DM Sans` para títulos e leitura limpa, combinadas com `JetBrains Mono` e `tabular-nums` obrigatório em todos os contadores de XP, frações de Combo Diário, horários e tabelas de níveis para evitar saltos de layout.
- **Disciplina de Metadados & Controles**:
  - Metadados estáticos (`+1 XP`, contagem de conclusões, faixa de XP do nível) exibidos como texto limpo e alinhado com separadores tipográficos (`·`), sem excesso de cápsulas decorativas.
  - Navegação principal em linha única (`whitespace-nowrap shrink-0`) e estados completos (estado vazio quando não há habilidades, feedback imediato ao concluir e transição de nível).

---

## 3. Key Product Decisions & Trade-Offs

- **Decisão 1: Regra Fixa de +1 XP e Curva Equilibrada dos 15 Níveis**
  - *Abordagem Escolhida*: Toda habilidade concluída vale exatamente **+1 XP**, com uma curva progressiva desenhada para essa escala (níveis iniciais exigem poucos pontos de XP para dar tração imediata nos primeiros dias, crescendo gradualmente até marcos de longo prazo no Nível 15).
  - *Por quê*: Se os níveis exigissem centenas de pontos logo no início com ganho de apenas `+1 XP`, o usuário demoraria semanas para sair do Nível 1; uma curva calibrada torna cada `+1 XP` tangível e recompensador.
  - *Alternativas Descartadas*: Pontuação variável por tarefa (`+5`, `+10`), pois contraria o pedido explícito de que toda habilidade ganhe `1 de XP`.

- **Decisão 2: Preservação de XP Histórico e Sincronização com Dados Existentes**
  - *Abordagem Escolhida*: O XP geral é derivado de forma consistente a partir do histórico de conclusões e do estado salvo de XP, hidratando automaticamente tarefas e logs já existentes no armazenamento local do navegador sem apagar o progresso anterior do usuário. Ao excluir uma tarefa antiga da lista, o histórico de XP já conquistado em dias anteriores permanece intacto, enquanto desmarcar no dia atual reverte o `+1 XP` daquela conclusão.
  - *Por quê*: Evita que o usuário perca XP acumulado ao limpar tarefas únicas concluídas ou reorganizar sua rotina, ao mesmo tempo em que impede abuso de marcar/desmarcar no mesmo dia.

- **Decisão 3: Auditoria Estruturada de Bugs Antes da Entrega**
  - *Abordagem Escolhida*: Expandir a suíte automatizada de testes e validar cenários limítrofes reais (virada de dia com tarefas pendentes, desmarcação de tarefa única concluída ontem, dados corrompidos no armazenamento, alternância rápida de áudio e consistência visual em claro/escuro).
  - *Por quê*: Garante que o sistema de XP e todos os recursos existentes operem juntos sem regressões ou estados inconsistentes.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Diagrama de Arquitetura e Fluxo

```
┌───────────────────────────────────────────────────────────────────────────┐
│                         Camada de Estado & Persistência                   │
│  Armazenamento Local (Tarefas, Logs, XP Total, Histórico, Diário, Vícios) │
└───────────────────────────────┬───────────────────────────────────────────┘
                                │ hidratação segura + virada automática 24h
                                ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                      Núcleo de Regras & Motor de XP                       │
│  • Motor de Progressão (15 Níveis Detalhados + Sub-nível por Habilidade)  │
│  • Cálculo de Combo Diário & XP Ganho Hoje                                │
│  • Reconciliação de Conclusão / Desmarcação (+1 XP / -1 XP)               │
│  • Motor de Áudio Web (5 Músicas + 6 Ambientes + Auto-Troca)              │
└───────────┬───────────────────────────┬───────────────────────┬───────────┘
            │                           │                       │
            ▼                           ▼                       ▼
┌───────────────────────┐   ┌───────────────────────┐   ┌───────────────────┐
│   Aba Tarefas & XP    │   │   Aba Níveis & XP     │   │  Diário & Vícios  │
│ • Lista (+1 XP)       │   │ • Patente 1..15       │   │ • Reflexão Diária │
│ • Combo Diário        │   │ • XP por Habilidade   │   │ • Recaída +       │
│ • XP Ganho Hoje       │   │ • Trilha Detalhada    │   │   Comentário      │
│ • Calendário & Heatmap│   │   dos 15 Níveis       │   │ • Marcos Limpos   │
└───────────────────────┘   └───────────────────────┘   └───────────────────┘
```

### Modelo de Dados & Estado

- **Habilidade / Tarefa**: Mantém título, tipo (`diária` ou `única`), estado de conclusão do dia, data/hora de conclusão e contagem total de conclusões (equivalente direta ao **XP próprio da tarefa**, já que cada conclusão vale `+1 XP`), além de nível/estágio individual da habilidade.
- **Progressão Global (15 Níveis)**: Catálogo fixo e bem detalhado com 15 níveis (`Nível 1` a `Nível 15`), contendo XP mínimo acumulado, XP necessário para o próximo nível, título da patente, lema curto, descrição rica da etapa e categoria de maestria.
- **Resumo Diário (Combo & XP Hoje)**: Derivado em tempo real dos logs e conclusões válidas do dia local atual (`Combo Diário` medindo concluídas vs. meta diária e `XP ganho hoje` somando `+1 XP` por conclusão ativa do dia).
- **Persistência Segura**: Retrocompatível com os dados salvos anteriormente no navegador, com sanitização de campos inválidos ou ausentes para evitar falhas ao carregar.

### Mapeamento Interativo de Componentes & Estados

- **Cabeçalho Global**: Controla navegação entre as 4 abas (`Tarefas & Histórico`, `Níveis & XP`, `Seu Diário`, `Seus Vícios`), botão de simulação de novo dia, controles do mixer de áudio aleatório, efeito sonoro e alternância de tema claro/escuro.
- **Painel de Tarefas & Resumo Diário**:
  - Criação e edição em linha de tarefas, filtragem no heatmap e calendário de constância.
  - Cartões superiores/integrados de **Combo Diário** (barra de progresso dinâmica) e **XP ganho hoje** (total do dia + link rápido para abrir a aba de **Níveis & XP**).
  - Ao clicar em concluir/desmarcar: valida o estado atual da tarefa, atualiza os logs do dia exato da conclusão (corrigindo inclusive desmarcações de tarefas concluídas em dias anteriores), recalcula XP diário, XP da habilidade e nível global, dispara som e alerta se houver mudança de nível.
- **Painel de 15 Níveis & Habilidades**:
  - Exibe progresso detalhado do nível atual até o próximo, resumo das estatísticas de XP, seção com todas as habilidades e seus respectivos XPs/níveis individuais, e a grade/lista completa dos 15 níveis com filtros ou destaque visual do nível ativo, concluídos e bloqueados.
- **Suite de Testes & Auditoria de Bugs**:
  - Cobertura automatizada validando: cálculo dos 15 níveis nos limites exatos de XP, ganho e reversão de `+1 XP` ao marcar/desmarcar, preservação de XP ao limpar ou simular novo dia, atualização de datas à meia-noite, comentários em recaídas e ciclos do motor de áudio.
